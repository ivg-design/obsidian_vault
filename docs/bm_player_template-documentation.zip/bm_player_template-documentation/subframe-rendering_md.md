---
title: Subframe rendering
type: documentation
project: bm_player_template
source: /Users/ivg/github/bm_player_template/docs/subframe-rendering.md
created: 08-30-2025 22:30:09
modified: 08-30-2025 22:30:09
tags:
  - #bm_player_template
  - #type/documentation
---

I'll analyze the project structure and generate comprehensive documentation for the Lottie Animation Player template.