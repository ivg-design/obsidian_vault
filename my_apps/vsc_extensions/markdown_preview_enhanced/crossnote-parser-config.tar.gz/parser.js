// Grid Table Parser v5.0 – Performance optimized with proper cell borders
({
	onWillParseMarkdown: async function (markdown) {
		const DEBUG = false;

		// Pre-compiled regexes for performance
		const GRID_BORDER_RE = /^\s*\+(?:[-=]+(?:\+|$))+\s*$/;
		const GRID_LINE_RE = /^\s*[|+]/;
		const FENCE_RE = /^(\s*)(`{3,}|~{3,})(\w+)?\s*$/;

		if (DEBUG) {
			const ts = new Date().toLocaleTimeString();
			markdown = `<!-- Grid parser loaded at: ${ts} -->\n` + markdown;
		}

		const lines = markdown.split(/\r?\n/);
		const out = [];
		let i = 0;

		let inFence = false;
		let fenceChar = null;
		let fenceLen = 0;

		while (i < lines.length) {
			const raw = lines[i];
			const line = raw;

			// Check for fence boundaries
			const fm = line.match(FENCE_RE);
			if (fm) {
				const seq = fm[2];
				if (!inFence) {
					inFence = true;
					fenceChar = seq[0];
					fenceLen = seq.length;
				} else if (seq[0] === fenceChar && seq.length >= fenceLen) {
					inFence = false;
					fenceChar = null;
					fenceLen = 0;
				}
				out.push(raw);
				i++;
				continue;
			}

			// Parse grid table only outside fences
			if (!inFence && GRID_BORDER_RE.test(line)) {
				const { blockLines, nextIndex } = collectGridTableBlock(lines, i);
				const html = convertGridTableToHTML(blockLines);
				out.push(html);
				i = nextIndex;
				continue;
			}

			out.push(raw);
			i++;
		}

		return out.join('\n');

		/* ---------------------------- Helpers ---------------------------- */

		function collectGridTableBlock(lines, startIdx) {
			const block = [];
			let j = startIdx;

			const indentMatch = lines[startIdx].match(/^(\s*)\+/);
			const indent = indentMatch ? indentMatch[1] : '';

			while (j < lines.length) {
				const cur = lines[j];
				const trimmed = cur.trim();

				if (trimmed.length === 0) {
					block.push(cur);
					j++;
					// Two consecutive blanks end the table
					if (j < lines.length && lines[j].trim().length === 0) {
						break;
					}
					continue;
				}

				if (cur.startsWith(indent) && GRID_LINE_RE.test(cur.slice(indent.length))) {
					block.push(cur);
					j++;
				} else {
					break;
				}
			}

			return { blockLines: block, nextIndex: j };
		}

		function convertGridTableToHTML(lines) {
			// Trim empty lines
			while (lines.length > 0 && !lines[0].trim()) lines.shift();
			while (lines.length > 0 && !lines[lines.length - 1].trim()) lines.pop();

			if (lines.length < 3) return lines.join('\n');

			// Validate borders
			if (!GRID_BORDER_RE.test(lines[0]) || !GRID_BORDER_RE.test(lines[lines.length - 1])) {
				return lines.join('\n');
			}

			// Get column positions from first border
			const firstBorder = lines[0];
			const colIdxs = [];
			for (let i = 0; i < firstBorder.length; i++) {
				if (firstBorder[i] === '+') colIdxs.push(i);
			}
			if (colIdxs.length < 2) return lines.join('\n');

			// Fast validation of border alignment
			for (let k = 0; k < lines.length; k++) {
				if (GRID_BORDER_RE.test(lines[k])) {
					let plusCount = 0;
					for (const idx of colIdxs) {
						if (lines[k][idx] === '+') plusCount++;
					}
					if (plusCount !== colIdxs.length) return lines.join('\n');
				}
			}

			// Parse rows
			const rows = [];
			let headerDone = false;

			for (let i = 1; i < lines.length; ) {
				if (!GRID_BORDER_RE.test(lines[i])) {
					i++;
					continue;
				}

				const borderLine = lines[i];
				const isHeaderSep = borderLine.includes('=');
				i++;

				const accumCellLines = Array(colIdxs.length - 1)
					.fill(null)
					.map(() => []);

				// Collect content lines
				while (i < lines.length && !GRID_BORDER_RE.test(lines[i])) {
					const content = lines[i];
					const cols = sliceByColumns(content, colIdxs);
					for (let c = 0; c < cols.length; c++) {
						accumCellLines[c].push(cols[c].trimEnd());
					}
					i++;
				}

				if (i >= lines.length) break;

				rows.push({
					isHeader: !headerDone && isHeaderSep,
					cells: accumCellLines,
				});

				if (isHeaderSep) headerDone = true;
			}

			if (rows.length === 0) return lines.join('\n');

			// Build HTML
			let html = '<table class="grid-table">\n';

			const headerRows = rows.filter((r) => r.isHeader);
			const bodyRows = rows.filter((r) => !r.isHeader);

			if (headerRows.length > 0) {
				html += '<thead>\n';
				for (const row of headerRows) {
					html += '<tr>';
					for (const cell of row.cells) {
						html += `<th>${processCellContent(cell)}</th>`;
					}
					html += '</tr>\n';
				}
				html += '</thead>\n';
			}

			if (bodyRows.length > 0) {
				html += '<tbody>\n';
				for (const row of bodyRows) {
					html += '<tr>';
					for (const cell of row.cells) {
						html += `<td>${processCellContent(cell)}</td>`;
					}
					html += '</tr>\n';
				}
				html += '</tbody>\n';
			}

			html += '</table>\n';
			return html;
		}

		function sliceByColumns(line, colIdxs) {
			// Ensure line is long enough
			const needLen = colIdxs[colIdxs.length - 1] + 1;
			if (line.length < needLen) {
				line += ' '.repeat(needLen - line.length);
			}

			const cells = [];
			for (let i = 0; i < colIdxs.length - 1; i++) {
				const start = colIdxs[i] + 1;
				const end = colIdxs[i + 1];
				let slice = line.substring(start, end);
				// Remove trailing pipe and spaces
				slice = slice.replace(/\s*\|?\s*$/, '');
				// Remove leading spaces
				slice = slice.replace(/^\s*/, '');
				cells.push(slice);
			}
			return cells;
		}

		function processCellContent(cellLines) {
			const CODE_SPAN_RE = /`([^`]+)`/g;
			const IMG_RE = /!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g;
			const LINK_RE = /\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g;
			const BOLD_RE = /(\*\*|__)([^]+?)\1/g;
			const ITALIC_STAR_RE = /(^|[^*])\*([^*\n]+)\*(?!\*)/g;
			const ITALIC_UNDER_RE = /(^|[^_])_([^_\n]+)_(?!_)/g;
			const HTML_TAG_RE = /<(pre|code|span|div|p|br|hr|strong|em|b|i|u|a|img)(\s[^>]*)?>(.*?)<\/\1>|<(br|hr|img)(\s[^>]*)?\/?>/gi;

			if (!cellLines || cellLines.length === 0) return '';

			const frags = [];
			let inFence = false;
			let fenceLang = '';
			let fenceBuf = [];
			let para = [];

			function flushPara() {
				if (para.length > 0) {
					// Check if all lines are list items
					const isUnorderedList = para.every((line) => /^\s*[-*+]\s+/.test(line));
					const isOrderedList = para.every((line) => /^\s*\d+\.\s+/.test(line));

					if (isUnorderedList) {
						frags.push('<ul>');
						para.forEach((line) => {
							const content = line.replace(/^\s*[-*+]\s+/, '');
							frags.push(`<li>${processMarkdown(content)}</li>`);
						});
						frags.push('</ul>');
					} else if (isOrderedList) {
						frags.push('<ol>');
						para.forEach((line) => {
							const content = line.replace(/^\s*\d+\.\s+/, '');
							frags.push(`<li>${processMarkdown(content)}</li>`);
						});
						frags.push('</ol>');
					} else {
						// Mix of list and non-list: process line by line
						let inList = false;
						let listType = null;
						let listItems = [];

						para.forEach((line) => {
							const unorderedMatch = /^\s*[-*+]\s+/.test(line);
							const orderedMatch = /^\s*\d+\.\s+/.test(line);

							if (unorderedMatch || orderedMatch) {
								if (!inList) {
									inList = true;
									listType = unorderedMatch ? 'ul' : 'ol';
									listItems = [];
								}
								const content = line.replace(/^\s*[-*+\d]+\.?\s+/, '');
								listItems.push(`<li>${processMarkdown(content)}</li>`);
							} else {
								if (inList) {
									frags.push(`<${listType}>${listItems.join('')}</${listType}>`);
									inList = false;
									listItems = [];
								}
								frags.push(`<div class="cell-paragraph">${processMarkdown(line)}</div>`);
							}
						});

						// Flush remaining list
						if (inList && listItems.length > 0) {
							frags.push(`<${listType}>${listItems.join('')}</${listType}>`);
						}
					}
					para = [];
				}
			}

			function flushFence() {
				const code = escapeHtml(fenceBuf.join('\n'));
				const cls = fenceLang ? ` class="language-${fenceLang}"` : '';
				frags.push(`<pre><code${cls}>${code}</code></pre>`);
				fenceBuf = [];
				fenceLang = '';
			}

			for (const raw of cellLines) {
				const line = raw.replace(/\r$/, '');

				const m = line.match(FENCE_RE);
				if (m) {
					if (!inFence) {
						flushPara();
						inFence = true;
						fenceLang = m[3] || '';
					} else {
						inFence = false;
						flushFence();
					}
					continue;
				}

				if (inFence) {
					fenceBuf.push(line);
					continue;
				}

				// Check if this line starts a list
				const isListItem = /^\s*[-*+]\s+/.test(line) || /^\s*\d+\.\s+/.test(line);

				if (line.trim() === '') {
					flushPara();
					frags.push('<div class="cell-paragraph"></div>');
				} else if (isListItem && para.length > 0 && !/^\s*[-*+]\s+/.test(para[para.length - 1]) && !/^\s*\d+\.\s+/.test(para[para.length - 1])) {
					// Starting a new list after non-list content
					flushPara();
					para.push(line);
				} else {
					para.push(line);
				}
			}

			if (inFence) flushFence();
			if (para.length > 0) flushPara();

			return frags.join('\n');

			function processMarkdown(text) {
				if (!text) return '';

				// Handle HTML tags first (preserve them without escaping)
				const htmlFragments = [];
				let htmlIndex = 0;

				text = text.replace(HTML_TAG_RE, (match) => {
					const placeholder = `\u0000HTML${htmlIndex}\u0000`;
					htmlFragments.push(match); // Keep HTML as-is, including <pre> with inner HTML
					htmlIndex++;
					return placeholder;
				});

				// Escape remaining HTML entities (but not the placeholders)
				text = escapeHtml(text);

				// Process inline code (protect from other replacements)
				const codeSpans = [];
				text = text.replace(CODE_SPAN_RE, (_, g1) => {
					const idx = codeSpans.length;
					codeSpans.push(g1);
					return `\u0000CODE${idx}\u0000`;
				});

				// Process markdown elements
				text = text.replace(IMG_RE, '<img alt="$1" src="$2">');
				text = text.replace(LINK_RE, '<a href="$2">$1</a>');
				text = text.replace(BOLD_RE, '<strong>$2</strong>');
				text = text.replace(ITALIC_STAR_RE, '$1<em>$2</em>');
				text = text.replace(ITALIC_UNDER_RE, '$1<em>$2</em>');

				// Restore code spans
				text = text.replace(/\u0000CODE(\d+)\u0000/g, (_, i) => {
					return '<code>' + codeSpans[i] + '</code>';
				});

				// Restore HTML fragments
				text = text.replace(/\u0000HTML(\d+)\u0000/g, (_, i) => {
					return htmlFragments[i];
				});

				return text;
			}

			function escapeHtml(text) {
				return text
					.replace(/&/g, '&amp;')
					.replace(/</g, '&lt;')
					.replace(/>/g, '&gt;')
					.replace(/"/g, '&quot;')
					.replace(/'/g, '&#39;')
					.replace(/\\([*_`\[\]])/g, '$1');
			}
		}
	},

	onDidParseMarkdown: async function (html) {
		if (html.indexOf('id="mpe-gridtable-styles"') !== -1) {
			return html;
		}

		const styles = `
<style id="mpe-gridtable-styles">
  /* GRID TABLE STYLES v5.0 - Multiline cells without internal borders */
  .grid-table {
    border-collapse: separate;
    border-spacing: 0;
    width: 100%;
    margin: 1em 0;
    background: #fff;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    border: 1px solid #d0d7de;
  }
  
  .grid-table th,
  .grid-table td {
    padding: 12px 16px;
    text-align: left;
    vertical-align: top;
    line-height: 1.6;
    position: relative;
  }
  
  /* Border styling - only between different cells */
  .grid-table th + th,
  .grid-table td + td {
    border-left: 1px solid #d0d7de;
  }
  
  .grid-table thead tr:last-child th,
  .grid-table tbody tr:not(:last-child) td {
    border-bottom: 1px solid #d0d7de;
  }
  
  .grid-table thead + tbody tr:first-child td {
    border-top: 1px solid #d0d7de;
  }
  
  .grid-table th {
    background: #f6f8fa;
    font-weight: 600;
    color: #24292f;
    font-size: 14px;
  }
  
  .grid-table tbody tr:nth-child(even) {
    background: rgba(246, 248, 250, .5);
  }
  
  .grid-table tbody tr:hover {
    background: #f3f4f6;
  }
  
  /* Code styling */
  .grid-table code {
    background: rgba(175, 184, 193, .2);
    padding: .2em .4em;
    border-radius: 3px;
    font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
    font-size: 85%;
    color: #0550ae;
    font-weight: 500;
  }
  
  .grid-table pre {
    background: #f6f8fa;
    border: 1px solid #d1d5da;
    border-radius: 6px;
    padding: 12px;
    overflow-x: auto;
    margin: 8px 0;
    font-size: 85%;
    line-height: 1.45;
  }
  
  .grid-table pre code {
    background: transparent;
    padding: 0;
    color: #24292f;
    font-size: 100%;
  }
  
  /* Multiline cell content */
  .cell-paragraph {
    margin: 0 0 8px 0;
  }
  
  .cell-paragraph:last-child {
    margin-bottom: 0;
  }
  
  .cell-paragraph:empty {
    height: .5em;
  }
  
  /* List styling inside cells */
  .grid-table ul,
  .grid-table ol {
    margin: 8px 0;
    padding-left: 20px;
  }
  
  .grid-table li {
    margin: 4px 0;
    line-height: 1.6;
  }
  
  .grid-table ul {
    list-style-type: disc;
  }
  
  .grid-table ol {
    list-style-type: decimal;
  }
  
  /* Nested lists */
  .grid-table ul ul,
  .grid-table ol ol,
  .grid-table ul ol,
  .grid-table ol ul {
    margin: 4px 0;
  }
</style>`;
		return styles + html;
	},
});
